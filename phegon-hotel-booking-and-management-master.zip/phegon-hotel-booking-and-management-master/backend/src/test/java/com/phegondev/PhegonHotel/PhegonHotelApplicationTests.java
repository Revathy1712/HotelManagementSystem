package com.phegondev.PhegonHotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhegonHotelApplicationTests {

	@Test
	void contextLoads() {
	}

}
